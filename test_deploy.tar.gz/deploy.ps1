# Configurações do Servidor
$IP = "82.25.68.234"
$USER = "root"
$REMOTE_PATH = "/root/saas-delivery"

Write-Host "--- INICIANDO DEPLOY ---" -ForegroundColor Cyan

# 1. Limpando resíduos locais
Write-Host "1. Preparando arquivos..."
if (Test-Path "deploy_package.tar.gz") { Remove-Item "deploy_package.tar.gz" }

# 2. Compactando projeto (Usando tar)
# Incluindo o .env para que o servidor tenha as chaves de produção
tar --exclude="node_modules" --exclude=".next" --exclude=".git" -czf deploy_package.tar.gz .

# 3. Criando diretório remoto e enviando
Write-Host "2. Enviando para o servidor ($IP)..."
ssh $USER@$IP "mkdir -p $REMOTE_PATH"
scp deploy_package.tar.gz "$USER@$($IP):$REMOTE_PATH"

# 4. Extraindo e subindo Docker
Write-Host "3. Limpando servidor e extraindo novos arquivos..."
$remoteCommands = @"
cd $REMOTE_PATH
tar -xzf deploy_package.tar.gz --overwrite
rm deploy_package.tar.gz
docker compose up -d --build
"@

ssh $USER@$IP $remoteCommands

# 5. Limpeza local
Remove-Item "deploy_package.tar.gz"

Write-Host "--- DEPLOY CONCLUÍDO COM SUCESSO! ---" -ForegroundColor Green
Write-Host "Sua aplicação está subindo em: http://$IP:3000"
