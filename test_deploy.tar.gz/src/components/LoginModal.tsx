"use client";

import { useState } from "react";
import { Mail, Lock, Eye, EyeOff, Loader2, X, ArrowRight } from "lucide-react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import toast from "react-hot-toast";

export function LoginModal({ onClose, onRegisterClick }: { onClose: () => void, onRegisterClick?: () => void }) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [showPass, setShowPass] = useState(false);
  const [form, setForm] = useState({
    email: "",
    password: ""
  });

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    
    try {
      const result = await signIn("credentials", {
        email: form.email,
        password: form.password,
        redirect: false,
      });

      if (result?.error) {
        toast.error("E-mail ou senha incorretos");
      } else {
        toast.success("Login realizado com sucesso!");
        router.push("/dashboard");
        onClose();
      }
    } catch (error) {
      toast.error("Erro ao realizar login");
    } finally {
      setLoading(false);
    }
  }

  return (
     <div className="w-full max-w-md bg-white border border-slate-100 rounded-[32px] p-10 shadow-2xl relative overflow-hidden animate-in fade-in zoom-in-95 duration-300">
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-purple-500/5 blur-[80px] pointer-events-none" />
        
        <div className="text-center mb-10">
           <h2 className="text-3xl font-black text-slate-900 uppercase tracking-tighter">Bem-vindo de volta</h2>
           <p className="text-slate-400 text-xs font-bold uppercase tracking-widest mt-2">Acesse sua plataforma de gestão</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
           <div className="group">
              <label className="text-[10px] font-black uppercase text-slate-400 ml-1 mb-1 block tracking-widest">Seu E-mail</label>
              <div className="relative">
                 <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300 group-focus-within:text-purple-500 transition-colors" />
                 <input 
                    type="email" 
                    required
                    value={form.email}
                    onChange={e => setForm({...form, email: e.target.value})}
                    placeholder="voce@exemplo.com"
                    className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 pl-12 pr-4 text-slate-900 font-bold placeholder:text-slate-300 focus:outline-none focus:border-purple-500 transition-all"
                 />
              </div>
           </div>

           <div className="group">
              <label className="text-[10px] font-black uppercase text-slate-400 ml-1 mb-1 block tracking-widest">Sua Senha</label>
              <div className="relative">
                 <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300 group-focus-within:text-purple-500 transition-colors" />
                 <input 
                    type={showPass ? "text" : "password"} 
                    required
                    value={form.password}
                    onChange={e => setForm({...form, password: e.target.value})}
                    placeholder="••••••••"
                    className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 pl-12 pr-12 text-slate-900 font-bold placeholder:text-slate-300 focus:outline-none focus:border-purple-500 transition-all"
                 />
                 <button type="button" onClick={() => setShowPass(!showPass)} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-300 hover:text-slate-900 transition-colors">
                    {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
                 </button>
              </div>
           </div>

           <button 
              type="submit"
              disabled={loading}
              className="w-full bg-slate-900 hover:bg-purple-600 text-white font-black py-5 rounded-2xl flex items-center justify-center gap-2 transition-all disabled:opacity-50 shadow-xl"
           >
              {loading ? <Loader2 className="animate-spin" size={18} /> : (
                 <>ENTRAR NO PAINEL <ArrowRight size={18} /></>
              )}
           </button>
        </form>

        <div className="mt-8 pt-8 border-t border-slate-100 text-center">
           <p className="text-xs text-slate-400 font-bold uppercase tracking-tight">
              Ainda não tem conta? <button onClick={onRegisterClick} className="text-purple-600 hover:underline">Crie agora</button>
           </p>
        </div>
     </div>
  );
}
