"use client";

import { useState, useEffect } from "react";
import { 
  Search, 
  Package, 
  Clock, 
  X, 
  Phone,
  ArrowRight,
  ClipboardList
} from "lucide-react";

interface Product {
  id: string;
  name: string;
  description?: string;
  price: number;
  imageUrl?: string;
  isActive: boolean;
  categoryId: string;
}

interface StoreData {
  name: string;
  logo?: string;
  coverImage?: string;
  primaryColor?: string;
  whatsapp?: string;
  description?: string;
  openingHours?: string;
  banners?: string[];
}

interface ServicePageProps {
  store: StoreData;
  products: Product[];
  categories: any[];
}

export default function ServiceCatalog({ store, products, categories }: ServicePageProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [activeCategory, setActiveCategory] = useState<string>("all");
  const [currentBannerIndex, setCurrentBannerIndex] = useState(0);

  const primaryColor = store.primaryColor || "#575799";
  const banners = (store.banners || []).filter(url => url && typeof url === 'string');

  useEffect(() => {
    if (banners.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentBannerIndex(prev => (prev + 1) % banners.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [banners.length]);

  const filteredProducts = products.filter(p => {
    const matchSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchCategory = activeCategory === "all" || p.categoryId === activeCategory;
    return matchSearch && matchCategory && p.isActive;
  });

  function requestQuote(product: Product) {
    const msg = encodeURIComponent(
      `Olá! Gostaria de um orçamento para o serviço:\n\n` +
      `*${product.name}*\n` +
      (product.description ? `Descrição: ${product.description}\n` : "") +
      `Preço base: R$ ${product.price.toFixed(2)}\n\n` +
      `Pode me passar mais informações?`
    );
    window.open(`https://wa.me/${store.whatsapp}?text=${msg}`, '_blank');
  }

  return (
    <div className="min-h-screen bg-white" style={{ fontFamily: "'Inter', sans-serif" }}>
      
      {/* Header / Brand Section */}
      <div className="bg-slate-50 border-b border-slate-100 py-12 px-4">
         <div className="max-w-4xl mx-auto flex flex-col md:flex-row items-center gap-8">
            <div className="w-32 h-32 bg-white rounded-3xl shadow-xl p-2 border-4 border-white overflow-hidden flex-shrink-0">
               {store.logo ? (
                  <img src={store.logo} className="w-full h-full object-cover rounded-2xl" alt="Logo" />
               ) : (
                  <div className="w-full h-full flex items-center justify-center text-slate-200">
                     <ClipboardList size={40} />
                  </div>
               )}
            </div>
            <div className="text-center md:text-left">
               <h1 className="text-4xl font-black text-slate-900 tracking-tighter uppercase">{store.name}</h1>
               <p className="text-slate-400 text-sm font-medium mt-2 max-w-lg">{store.description || "Soluções em prestação de serviços e papelaria."}</p>
               <div className="flex flex-wrap justify-center md:justify-start gap-4 mt-6">
                  <a 
                    href={`https://wa.me/${store.whatsapp}`} 
                    target="_blank"
                    className="flex items-center gap-2 px-6 py-3 bg-green-500 text-white rounded-xl text-xs font-black uppercase tracking-widest hover:brightness-110 transition-all shadow-lg shadow-green-500/20"
                  >
                     <Phone size={14} /> Falar no WhatsApp
                  </a>
               </div>
            </div>
         </div>
      </div>

      {/* Banners Section */}
      {banners.length > 0 && (
        <div className="max-w-5xl mx-auto px-4 -mt-10 mb-20 relative z-20">
           <div className="relative h-[200px] md:h-[400px] rounded-[40px] overflow-hidden shadow-2xl border-8 border-white">
              {banners.map((url, idx) => (
                 <div 
                   key={idx}
                   className={`absolute inset-0 transition-opacity duration-1000 ${idx === currentBannerIndex ? 'opacity-100' : 'opacity-0'}`}
                 >
                    <img src={url} className="w-full h-full object-cover" alt="Banner" />
                    <div className="absolute inset-0 bg-black/10" />
                 </div>
              ))}
              
              {banners.length > 1 && (
                 <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-2 z-10">
                    {banners.map((_, idx) => (
                       <button 
                         key={idx}
                         onClick={() => setCurrentBannerIndex(idx)}
                         className={`h-1.5 rounded-full transition-all ${idx === currentBannerIndex ? 'bg-white w-8' : 'bg-white/40 w-2'}`}
                       />
                    ))}
                 </div>
              )}
           </div>
        </div>
      )}

      {/* Search & Filters */}
      <div className="max-w-4xl mx-auto px-4 mb-16">
         <div className="bg-slate-50 p-2 rounded-2xl flex flex-col md:flex-row gap-2">
            <div className="relative flex-1">
               <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
               <input 
                  type="text"
                  placeholder="Buscar serviço..."
                  className="w-full pl-12 pr-4 py-4 bg-white border border-slate-100 rounded-xl outline-none focus:border-brand transition-all text-xs font-bold uppercase tracking-widest"
                  value={searchTerm}
                  onChange={e => setSearchTerm(e.target.value)}
                  style={{'--brand': primaryColor} as any}
               />
            </div>
            <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1 md:pb-0">
               <button 
                  onClick={() => setActiveCategory("all")}
                  className={`px-8 py-4 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeCategory === "all" ? 'text-white' : 'text-slate-400 hover:text-slate-600 bg-white border border-slate-100'}`}
                  style={activeCategory === "all" ? { backgroundColor: primaryColor } : {}}
               >
                  Todos
               </button>
               {categories.map(cat => (
                  <button 
                     key={cat.id}
                     onClick={() => setActiveCategory(cat.id)}
                     className={`px-8 py-4 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${activeCategory === cat.id ? 'text-white' : 'text-slate-400 hover:text-slate-600 bg-white border border-slate-100'}`}
                     style={activeCategory === cat.id ? { backgroundColor: primaryColor } : {}}
                  >
                     {cat.emoji} {cat.name}
                  </button>
               ))}
            </div>
         </div>
      </div>

      {/* Services Grid */}
      <div className="max-w-4xl mx-auto px-4 pb-32">
         <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {filteredProducts.map(service => (
               <div 
                 key={service.id}
                 className="group bg-white rounded-[32px] border border-slate-100 p-6 flex flex-col hover:shadow-2xl hover:-translate-y-1 transition-all duration-300"
               >
                  <div className="aspect-video w-full bg-slate-50 rounded-2xl mb-6 overflow-hidden relative">
                     {service.imageUrl ? (
                        <img src={service.imageUrl} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" alt={service.name} />
                     ) : (
                        <div className="w-full h-full flex items-center justify-center text-slate-100">
                           <Package size={40} />
                        </div>
                     )}
                     <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-md px-4 py-2 rounded-full border border-white/20">
                        <span className="text-[10px] font-black text-slate-900 uppercase tracking-widest">Sob Consulta</span>
                     </div>
                  </div>
                  
                  <div className="flex-1 flex flex-col">
                     <div className="flex justify-between items-start mb-3">
                        <h3 className="text-xl font-black text-slate-900 uppercase tracking-tight leading-none">{service.name}</h3>
                        <span className="font-black text-lg text-brand" style={{ color: primaryColor }}>R$ {service.price.toFixed(2).replace('.', ',')}</span>
                     </div>
                     <p className="text-slate-400 text-xs font-medium mb-8 line-clamp-3 leading-relaxed">
                        {service.description || "Solicite um orçamento detalhado para este serviço."}
                     </p>
                     
                     <button 
                       onClick={() => requestQuote(service)}
                       className="w-full py-5 bg-slate-900 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-3 hover:brightness-110 transition-all shadow-xl group-hover:bg-brand"
                       style={{'--brand': primaryColor} as any}
                     >
                        Solicitar Orçamento <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
                     </button>
                  </div>
               </div>
            ))}
         </div>

         {filteredProducts.length === 0 && (
            <div className="text-center py-20 bg-slate-50 rounded-[40px] border border-slate-100 border-dashed">
               <Package size={48} className="mx-auto text-slate-200 mb-4" />
               <p className="text-slate-400 text-xs font-black uppercase tracking-widest">Nenhum serviço encontrado</p>
            </div>
         )}
      </div>

      <footer className="py-12 border-t border-slate-100 text-center">
         <p className="text-[9px] font-black text-slate-200 uppercase tracking-widest">Pedeue • Sistema para Prestação de Serviços</p>
      </footer>
    </div>
  );
}
