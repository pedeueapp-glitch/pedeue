"use client";

import { useState, useEffect } from "react";
import { 
  ShoppingBag, Search, User, Calendar, 
  Trash2, Plus, X, Loader2, FileText, Download,
  Tag, CreditCard, Banknote, Smartphone, Printer, CheckCircle2
} from "lucide-react";
import toast from "react-hot-toast";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

export default function ServicePDV({ storeId }: { storeId: string }) {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [products, setProducts] = useState<any[]>([]);
  const [customers, setCustomers] = useState<any[]>([]);
  const [store, setStore] = useState<any>(null);
  
  // PDV State
  const [cart, setCart] = useState<any[]>([]);
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null);
  const [deadline, setDeadline] = useState("");
  const [discount, setDiscount] = useState("0");
  const [paymentMethod, setPaymentMethod] = useState("DINHEIRO");
  const [searchTerm, setSearchTerm] = useState("");
  const [customerSearch, setCustomerSearch] = useState("");

  const fetchData = async () => {
    setLoading(true);
    try {
      const [prodRes, custRes, storeRes] = await Promise.all([
        fetch("/api/products"),
        fetch("/api/customers"),
        fetch("/api/store")
      ]);
      setProducts(await prodRes.json());
      setCustomers(await custRes.json());
      setStore(await storeRes.json());
    } catch { toast.error("Erro ao carregar dados"); } finally { setLoading(false); }
  };

  useEffect(() => { fetchData(); }, []);

  const addToCart = (product: any) => {
    setCart(prev => {
      const exists = prev.find(i => i.id === product.id);
      if (exists) return prev.map(i => i.id === product.id ? { ...i, quantity: i.quantity + 1 } : i);
      return [...prev, { ...product, price: product.salePrice || product.price, quantity: 1 }];
    });
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(i => i.id !== id));
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(i => {
      if (i.id === id) {
        const newQty = Math.max(1, i.quantity + delta);
        return { ...i, quantity: newQty };
      }
      return i;
    }));
  };

  const subtotal = cart.reduce((acc, i) => acc + (i.price * i.quantity), 0);
  const total = Math.max(0, subtotal - parseFloat(discount || "0"));

  const handleFinish = async () => {
    if (!selectedCustomer) return toast.error("Selecione um cliente");
    if (cart.length === 0) return toast.error("O carrinho está vazio");
    if (!deadline) return toast.error("Defina o prazo de entrega");

    setSaving(true);
    try {
      const res = await fetch("/api/orders/internal", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerId: selectedCustomer.id,
          customerName: selectedCustomer.name,
          customerPhone: selectedCustomer.phone,
          items: cart.map(i => ({
            productId: i.id,
            productName: i.name,
            price: i.price,
            quantity: i.quantity
          })),
          total: total,
          subtotal: subtotal,
          discount: parseFloat(discount),
          paymentMethod: paymentMethod,
          deliveryDeadline: new Date(deadline).toISOString(),
          orderType: "SERVICE"
        })
      });

      if (!res.ok) throw new Error();
      toast.success("Pedido/Orçamento gerado!");
      setCart([]);
      setSelectedCustomer(null);
      setDeadline("");
      setDiscount("0");
    } catch {
      toast.error("Erro ao salvar pedido");
    } finally {
      setSaving(false);
    }
  };

  const generatePDF = () => {
    if (!selectedCustomer) return toast.error("Selecione um cliente para gerar o PDF");
    if (cart.length === 0) return toast.error("Adicione itens para gerar o orçamento");

    const doc = new jsPDF() as any;
    
    // Header
    doc.setFontSize(22);
    doc.setTextColor(15, 23, 42); // Navy
    doc.text(store?.name || "Orçamento de Serviço", 20, 30);
    
    doc.setFontSize(10);
    doc.setTextColor(100, 116, 139); // Slate
    doc.text(`Data: ${new Date().toLocaleDateString('pt-BR')}`, 20, 40);
    doc.text(`Prazo de Entrega: ${deadline ? new Date(deadline).toLocaleDateString('pt-BR') : "A combinar"}`, 20, 45);

    // Cliente
    doc.setFontSize(12);
    doc.setTextColor(15, 23, 42);
    doc.text("Cliente:", 20, 60);
    doc.setFontSize(10);
    doc.text(selectedCustomer.name, 20, 67);
    doc.text(selectedCustomer.phone, 20, 72);
    if (selectedCustomer.street) {
        doc.text(`${selectedCustomer.street}, ${selectedCustomer.number} - ${selectedCustomer.neighborhood}`, 20, 77);
    }

    // Tabela de Itens
    const tableData = cart.map(i => [
        i.name,
        i.quantity.toString(),
        `R$ ${i.price.toFixed(2)}`,
        `R$ ${(i.price * i.quantity).toFixed(2)}`
    ]);

    autoTable(doc, {
      startY: 90,
      head: [['Produto/Serviço', 'Qtd', 'Preço Unit.', 'Total']],
      body: tableData,
      theme: 'grid',
      headStyles: { fillColor: [139, 92, 246] }, // Purple
      margin: { left: 20, right: 20 }
    });

    // Totais
    const finalY = (doc as any).lastAutoTable.finalY + 10;
    doc.setFontSize(10);
    doc.text(`Subtotal: R$ ${subtotal.toFixed(2)}`, 140, finalY);
    doc.text(`Desconto: R$ ${parseFloat(discount).toFixed(2)}`, 140, finalY + 7);
    doc.setFontSize(14);
    doc.text(`TOTAL: R$ ${total.toFixed(2)}`, 140, finalY + 17);

    doc.save(`Orcamento_${selectedCustomer.name.replace(/\s+/g, '_')}.pdf`);
    toast.success("PDF gerado com sucesso!");
  };

  const filteredProducts = products.filter(p => p.name.toLowerCase().includes(searchTerm.toLowerCase()));
  const filteredCustomers = customers.filter(c => c.name.toLowerCase().includes(customerSearch.toLowerCase()) || c.phone.includes(customerSearch));

  if (loading) return <div className="flex-1 flex items-center justify-center"><Loader2 className="animate-spin text-purple-500" /></div>;

  return (
    <div className="flex flex-col lg:flex-row h-screen bg-slate-50 overflow-hidden relative">
      
      {/* PAINEL ESQUERDO: PRODUTOS E CLIENTES */}
      <div className="flex-1 flex flex-col h-full min-h-0 p-4 lg:p-6 overflow-hidden">
        
        {/* BUSCA DE PRODUTOS */}
        <div className="mb-6 relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            className="input-field pl-12 bg-white" 
            placeholder="Pesquisar produtos..." 
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
          />
        </div>

        <div className="flex-1 overflow-y-auto min-h-0 grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-8 gap-2 pb-32 lg:pb-10">
          {filteredProducts.map(p => (
            <button 
              key={p.id} 
              onClick={() => addToCart(p)}
              className="bg-white border border-slate-100 p-2 hover:border-purple-500 transition-all group flex flex-col items-center text-center shadow-sm"
            >
              <div className="w-10 h-10 bg-slate-50 rounded-lg overflow-hidden mb-1 flex items-center justify-center">
                 {p.imageUrl ? <img src={p.imageUrl} className="w-full h-full object-cover group-hover:scale-110 transition-transform" /> : <ShoppingBag size={18} className="text-slate-300" />}
              </div>
              <div className="w-full">
                <h4 className="text-[10px] font-bold text-navy line-clamp-1">{p.name}</h4>
                <p className="text-[11px] font-black text-purple-500 mt-0.5">R$ {p.price.toFixed(2).replace('.', ',')}</p>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* PAINEL DIREITO: CARRINHO E CHECKOUT (ABRE/FECHA NO MOBILE?) */}
      <div className="fixed lg:relative bottom-0 left-0 right-0 lg:w-[450px] bg-white border-t lg:border-t-0 lg:border-l border-slate-200 flex flex-col shadow-2xl z-[60] max-h-[85vh] lg:max-h-none transition-all duration-300">
        
        {/* BOTÃO PARA EXPANDIR NO MOBILE */}
        <div className="lg:hidden flex items-center justify-between p-4 border-b border-slate-100 bg-white sticky top-0 z-10">
           <div className="flex items-center gap-2">
              <ShoppingBag size={20} className="text-purple-500" />
              <span className="font-black uppercase text-[10px] text-navy">Resumo ({cart.length})</span>
           </div>
           <span className="text-sm font-black text-navy">R$ {total.toFixed(2)}</span>
        </div>
        
        {/* SELEÇÃO DE CLIENTE */}
        <div className="p-4 lg:p-6 border-b border-slate-100">
           <label className="text-[9px] lg:text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 lg:mb-3 block">Cliente do Orçamento</label>
           
           {selectedCustomer ? (
              <div className="flex items-center justify-between bg-purple-50 border border-purple-100 p-3 lg:p-4 rounded-2xl animate-in slide-in-from-top-2">
                 <div className="flex items-center gap-3">
                    <div className="w-8 h-8 lg:w-10 lg:h-10 bg-purple-500 text-white rounded-xl flex items-center justify-center">
                       <User size={16} className="lg:hidden" />
                       <User size={20} className="hidden lg:block" />
                    </div>
                    <div>
                       <h5 className="text-[11px] lg:text-sm font-bold text-navy">{selectedCustomer.name}</h5>
                       <p className="text-[9px] lg:text-[10px] text-purple-600 font-bold">{selectedCustomer.phone}</p>
                    </div>
                 </div>
                 <button onClick={() => setSelectedCustomer(null)} className="p-2 text-purple-300 hover:text-red-500 transition-colors">
                    <X size={16} />
                 </button>
              </div>
           ) : (
              <div className="relative group">
                 <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-300" size={14} />
                 <input 
                   className="input-field pl-10 !py-3 bg-slate-50 border-none text-[11px]" 
                   placeholder="Buscar ou selecionar cliente..."
                   value={customerSearch}
                   onChange={e => setCustomerSearch(e.target.value)}
                 />
                
                {customerSearch && filteredCustomers.length > 0 && (
                  <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-slate-100 rounded-2xl shadow-2xl z-50 max-h-60 overflow-y-auto overflow-hidden">
                    {filteredCustomers.map(c => (
                      <button 
                        key={c.id} 
                        onClick={() => { setSelectedCustomer(c); setCustomerSearch(""); }}
                        className="w-full p-4 text-left hover:bg-slate-50 flex items-center justify-between group"
                      >
                         <div>
                            <p className="text-xs font-bold text-navy">{c.name}</p>
                            <p className="text-[10px] text-slate-400">{c.phone}</p>
                         </div>
                         <Plus size={14} className="text-slate-200 group-hover:text-purple-500" />
                      </button>
                    ))}
                  </div>
                )}
             </div>
           )}
        </div>

        {/* CARRINHO */}
        <div className="flex-1 overflow-y-auto p-4 lg:p-6 space-y-3 lg:space-y-4">
           {cart.length === 0 ? (
             <div className="h-full flex flex-col items-center justify-center text-center opacity-20 py-10 lg:py-0">
                <ShoppingBag size={48} className="lg:hidden text-slate-400 mb-2" />
                <ShoppingBag size={60} className="hidden lg:block text-slate-400 mb-4" />
                <p className="text-[10px] lg:text-sm font-bold text-slate-500 uppercase tracking-widest">Carrinho Vazio</p>
             </div>
           ) : (
             cart.map(item => (
               <div key={item.id} className="flex gap-3 lg:gap-4 group">
                  <div className="w-12 h-12 lg:w-16 lg:h-16 bg-slate-50 rounded-xl overflow-hidden shrink-0 border border-slate-100">
                    {item.imageUrl && <img src={item.imageUrl} className="w-full h-full object-cover" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h5 className="text-[10px] lg:text-[11px] font-bold text-navy line-clamp-1">{item.name}</h5>
                    <div className="flex items-center justify-between mt-1 lg:mt-2">
                       <div className="flex items-center gap-2 lg:gap-3 bg-slate-50 rounded-lg p-0.5 lg:p-1 border border-slate-100">
                          <button onClick={() => updateQuantity(item.id, -1)} className="w-5 h-5 lg:w-6 lg:h-6 flex items-center justify-center text-slate-400 hover:text-navy hover:bg-white rounded-md transition-all">-</button>
                          <span className="text-[10px] lg:text-xs font-black text-navy w-4 text-center">{item.quantity}</span>
                          <button onClick={() => updateQuantity(item.id, 1)} className="w-5 h-5 lg:w-6 lg:h-6 flex items-center justify-center text-slate-400 hover:text-navy hover:bg-white rounded-md transition-all">+</button>
                       </div>
                       <span className="text-[10px] lg:text-xs font-black text-navy">R$ {(item.price * item.quantity).toFixed(2)}</span>
                       <button onClick={() => removeFromCart(item.id)} className="p-1 lg:p-2 text-slate-200 hover:text-red-500 transition-colors">
                          <Trash2 size={12} className="lg:hidden" />
                          <Trash2 size={14} className="hidden lg:block" />
                       </button>
                    </div>
                  </div>
               </div>
             ))
           )}
        </div>

        {/* FOOTER: PRAZO, DESCONTO, TOTAL */}
        <div className="p-6 lg:p-8 bg-slate-50 space-y-4 lg:space-y-5">
           
           <div className="grid grid-cols-2 gap-3 lg:gap-4">
              <div className="space-y-1 lg:space-y-2">
                 <label className="text-[8px] lg:text-[9px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-1">
                    <Calendar size={10} /> Prazo (Apenas Venda)
                 </label>
                 <input 
                  type="datetime-local" 
                  className="input-field !py-2 !text-[10px] lg:!text-[11px] bg-white border-none" 
                  value={deadline}
                  onChange={e => setDeadline(e.target.value)}
                 />
              </div>
              <div className="space-y-1 lg:space-y-2">
                 <label className="text-[8px] lg:text-[9px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-1">
                    <Tag size={10} /> Desconto (R$)
                 </label>
                 <input 
                  type="number" 
                  className="input-field !py-2 !text-[10px] lg:!text-[11px] bg-white border-none" 
                  value={discount}
                  onChange={e => setDiscount(e.target.value)}
                 />
              </div>
           </div>

           {/* FORMA DE PAGAMENTO */}
           <div className="grid grid-cols-3 gap-1.5 lg:gap-2">
              {[
                { id: "DINHEIRO", icon: Banknote, label: "Dinheiro" },
                { id: "CARTAO", icon: CreditCard, label: "Cartão" },
                { id: "PIX", icon: Smartphone, label: "Pix" }
              ].map(m => (
                <button 
                  key={m.id}
                  onClick={() => setPaymentMethod(m.id)}
                  className={`flex flex-col items-center justify-center p-2 lg:p-3 rounded-xl lg:rounded-2xl border transition-all ${paymentMethod === m.id ? 'bg-navy border-navy text-white shadow-lg' : 'bg-white border-slate-100 text-slate-400 hover:border-slate-300'}`}
                >
                   <m.icon size={14} className="lg:hidden mb-1" />
                   <m.icon size={16} className="hidden lg:block mb-1.5" />
                   <span className="text-[7px] lg:text-[8px] font-black uppercase">{m.label}</span>
                </button>
              ))}
           </div>

           <div className="pt-2 lg:pt-4 border-t border-slate-200">
              <div className="flex justify-between items-center mb-4 lg:mb-6">
                 <span className="text-[10px] lg:text-xs font-bold text-slate-500 uppercase tracking-widest">Total</span>
                 <span className="text-xl lg:text-2xl font-black text-navy">R$ {total.toFixed(2).replace('.', ',')}</span>
              </div>

              <div className="flex flex-col gap-2">
                 <button 
                  onClick={generatePDF}
                  className="w-full py-3.5 lg:py-4 bg-white border-2 border-slate-200 text-slate-600 rounded-xl lg:rounded-2xl font-black uppercase text-[9px] lg:text-[10px] tracking-widest flex items-center justify-center gap-2 hover:bg-slate-100 transition-all"
                 >
                    <Download size={16} /> Baixar Orçamento (Plano)
                 </button>
                 <button 
                  onClick={handleFinish}
                  disabled={saving}
                  className="w-full py-3.5 lg:py-4 bg-purple-500 text-white rounded-xl lg:rounded-2xl font-black uppercase text-[9px] lg:text-[10px] tracking-widest flex items-center justify-center gap-2 shadow-xl shadow-purple-500/20 hover:bg-purple-600 transition-all disabled:opacity-50"
                 >
                    {saving ? <Loader2 className="animate-spin" size={16} /> : <CheckCircle2 size={16} />}
                    Registrar Venda (Com Prazo)
                 </button>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
}
