import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: "Não autorizado" }, { status: 401 });

  const store = await prisma.store.findUnique({
    where: { userId: session.user.id }
  });

  if (!store) return NextResponse.json({ error: "Loja não encontrada" }, { status: 404 });

  // @ts-ignore
  const materials = await prisma.material.findMany({
    where: { storeId: store.id },
    orderBy: { createdAt: "desc" }
  });

  return NextResponse.json(materials);
}

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) return NextResponse.json({ error: "Não autorizado" }, { status: 401 });

  const store = await prisma.store.findUnique({
    where: { userId: session.user.id }
  });

  if (!store) return NextResponse.json({ error: "Loja não encontrada" }, { status: 404 });

  const body = await req.json();
  const { name, quantity, purchasePrice, profitMargin } = body;

  // @ts-ignore
  const material = await prisma.material.create({
    data: {
      name,
      quantity: parseInt(quantity),
      purchasePrice: parseFloat(purchasePrice),
      profitMargin: parseFloat(profitMargin),
      storeId: store.id
    }
  });

  return NextResponse.json(material);
}

export async function PATCH(req: Request) {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: "Não autorizado" }, { status: 401 });
  
    const body = await req.json();
    const { id, name, quantity, purchasePrice, profitMargin } = body;
  
    // @ts-ignore
    const material = await prisma.material.update({
      where: { id },
      data: {
        name,
        quantity: parseInt(quantity),
        purchasePrice: parseFloat(purchasePrice),
        profitMargin: parseFloat(profitMargin),
      }
    });
  
    return NextResponse.json(material);
}

export async function DELETE(req: Request) {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: "Não autorizado" }, { status: 401 });
  
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
  
    if (!id) return NextResponse.json({ error: "ID não fornecido" }, { status: 400 });
  
    // @ts-ignore
    await prisma.material.delete({
      where: { id }
    });
  
    return NextResponse.json({ success: true });
}
