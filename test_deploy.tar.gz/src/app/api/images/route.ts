import { NextRequest, NextResponse } from "next/server";
import path from "path";
import fs from "fs";

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const file = searchParams.get("file");

    if (!file) {
      return new NextResponse("Arquivo não especificado", { status: 400 });
    }

    // Limpeza básica do nome do arquivo por segurança
    const safeFile = file.replace(/[\/\\]/g, '');
    const filePath = path.join(process.cwd(), "public", "uploads", "products", safeFile);

    if (!fs.existsSync(filePath)) {
      console.error("Arquivo não encontrado no sistema:", filePath);
      return new NextResponse("Imagem não encontrada", { status: 404 });
    }

    const fileBuffer = fs.readFileSync(filePath);

    return new NextResponse(fileBuffer, {
      headers: {
        "Content-Type": "image/webp",
        "Cache-Control": "public, max-age=31536000, immutable",
      },
    });
  } catch (error) {
    console.error("Erro ao servir imagem:", error);
    return new NextResponse("Erro interno", { status: 500 });
  }
}
