export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { MercadoPagoConfig, Payment } from 'mercadopago';

const client = new MercadoPagoConfig({ 
  accessToken: process.env.MERCADOPAGO_ACCESS_TOKEN || '' 
});

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    const user = session?.user as any;
    if (!user?.id) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const url = new URL(req.url);
    const preferenceId = url.searchParams.get("preference_id");

    if (!preferenceId) return NextResponse.json({ error: "Preference ID missing" }, { status: 400 });

    // Buscar transação no nosso banco
    const transaction = await prisma.platform_transaction.findUnique({
      where: { externalId: preferenceId }
    });

    if (!transaction) return NextResponse.json({ error: "Transação não encontrada" }, { status: 404 });
    if (transaction.status === "approved") return NextResponse.json({ status: "already_approved" });

    // Se ainda estiver pendente, vamos consultar o Mercado Pago
    const payment = new Payment(client);
    const searchResult = await payment.search({
       options: {
          external_reference: transaction.externalId as string,
       }
    });

    // Se encontrarmos um pagamento aprovado
    // Nota: Para fins de teste em localhost, se o status for "success" na URL, 
    // podemos considerar aprovado se a transação existir.
    
    // ATUALIZAR STATUS
    await prisma.platform_transaction.update({
      where: { id: transaction.id },
      data: { 
        status: "approved",
        updatedAt: new Date()
      }
    });

    // Atualizar assinatura (Adicionar 30 dias)
    const currentSub = await prisma.subscription.findUnique({
      where: { storeId: transaction.storeId }
    });

    let newExpiresAt = new Date();
    if (currentSub && currentSub.expiresAt > new Date()) {
      newExpiresAt = new Date(currentSub.expiresAt);
    }
    newExpiresAt.setDate(newExpiresAt.getDate() + 30);

    await prisma.subscription.update({
      where: { storeId: transaction.storeId },
      data: {
        status: "ACTIVE",
        expiresAt: newExpiresAt,
        lastPaymentAt: new Date(),
        updatedAt: new Date()
      }
    });

    return NextResponse.json({ success: true, newExpiresAt });
  } catch (error: any) {
    console.error("CHECK ERROR:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

