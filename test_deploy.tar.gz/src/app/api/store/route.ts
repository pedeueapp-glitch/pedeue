export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

import { getCurrentStore } from "@/lib/get-store";

export async function GET(req: NextRequest) {
  try {
    const store = await getCurrentStore();
    if (!store) return NextResponse.json({ error: "Loja não encontrada" }, { status: 404 });

    return NextResponse.json(store);
  } catch (error: any) {
    return NextResponse.json({ error: "Erro ao buscar loja" }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) return NextResponse.json({ error: "Sessão expirada" }, { status: 401 });

    const body = await req.json();
    
    const { 
      name, 
      slug, 
      description, 
      whatsapp, 
      deliveryTime, 
      logo, 
      coverImage, 
      primaryColor,
      openingHours,
      isOpen,
      storeType,
      showcaseBanners,
      restaurantBanners,
      serviceBanners
    } = body;

    // 1. Validar Slug (se mudou)
    if (slug) {
      const cleanSlug = slug.trim().toLowerCase().replace(/[^a-z0-9-]/g, '');
      const existingStore = await prisma.store.findFirst({
        where: { 
          slug: cleanSlug,
          NOT: { userId: session.user.id }
        }
      });
      if (existingStore) {
        return NextResponse.json({ error: "Este link (slug) já existe. Escolha outro." }, { status: 400 });
      }
    }

    // 2. Montar objeto de atualização
    const dataToUpdate: any = {
      name: name || undefined,
      description: description !== undefined ? description : undefined,
      whatsapp: whatsapp !== undefined ? whatsapp : undefined,
      deliveryTime: deliveryTime ? String(deliveryTime) : undefined,
      logo: logo !== undefined ? logo : undefined,
      coverImage: coverImage !== undefined ? coverImage : undefined,
      primaryColor: primaryColor || undefined,
      isOpen: isOpen !== undefined ? Boolean(isOpen) : undefined,
      storeType: storeType || undefined,
      showcaseBanners: showcaseBanners !== undefined ? (typeof showcaseBanners === 'string' ? showcaseBanners : JSON.stringify(showcaseBanners)) : undefined,
      restaurantBanners: restaurantBanners !== undefined ? (typeof restaurantBanners === 'string' ? restaurantBanners : JSON.stringify(restaurantBanners)) : undefined,
      serviceBanners: serviceBanners !== undefined ? (typeof serviceBanners === 'string' ? serviceBanners : JSON.stringify(serviceBanners)) : undefined,
      openingHours: openingHours !== undefined ? (typeof openingHours === 'string' ? openingHours : JSON.stringify(openingHours)) : undefined,
    };

    if (slug) {
        dataToUpdate.slug = slug.trim().toLowerCase().replace(/[^a-z0-9-]/g, '');
    }

    // 3. Update - Usando uma abordagem mais resiliente
    let updatedStore;
    try {
      updatedStore = await prisma.store.update({
        where: { userId: session.user.id },
        data: dataToUpdate
      });
    } catch (prismaError: any) {
      console.warn("Retrying update without showcaseBanners due to type mismatch:", prismaError.message);
      // Fallback: tenta atualizar sem o campo problemático se o Prisma Client estiver desatualizado
      const { showcaseBanners: _, ...fallbackData } = dataToUpdate;
      updatedStore = await prisma.store.update({
        where: { userId: session.user.id },
        data: fallbackData as any
      });
    }

    return NextResponse.json(updatedStore);
  } catch (error: any) {
    console.error("DETAILED PRISMA ERROR:", error);
    return NextResponse.json({ 
      error: "Falha técnica ao salvar no banco.",
      details: error.message 
    }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  return PATCH(req);
}

