export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import sharp from "sharp";
import path from "path";
import fs from "fs/promises";
import { v4 as uuidv4 } from "uuid";

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) return NextResponse.json({ error: "Nao autorizado" }, { status: 401 });

    const formData = await req.formData();
    const file = formData.get("file") as File;

    if (!file) {
      return NextResponse.json({ error: "Arquivo nao fornecido" }, { status: 400 });
    }

    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);

    // Definir diretório de upload (dentro de public para ser acessível via URL)
    const uploadDir = path.join(process.cwd(), "public", "uploads", "products");
    
    // Garantir que a pasta existe
    try {
      await fs.access(uploadDir);
    } catch {
      await fs.mkdir(uploadDir, { recursive: true });
    }

    // Nome do arquivo sempre .webp para padronização e performance
    const filename = `${uuidv4()}.webp`;
    const filepath = path.join(uploadDir, filename);

    // PROCESSAMENTO COM SHARP:
    // 1. Redimensionar para max 1000x1000 (preservando aspecto)
    // 2. Converter para WebP com qualidade 75 (equilíbrio entre peso e qualidade)
    // 3. Remover EXIF
    await sharp(buffer)
      .resize(1000, 1000, { fit: "inside", withoutEnlargement: true })
      .webp({ quality: 75 })
      .toFile(filepath);

    // Retorna a URL através da nossa API de serviço de imagens
    // Isso garante que a imagem carregue em produção (Standalone) bypassando limitações da pasta public
    const serveUrl = `/api/images?file=${filename}`;

    return NextResponse.json({ url: serveUrl });
  } catch (error: any) {
    console.error("ERRO UPLOAD LOCAL:", error);
    return NextResponse.json({ error: "Falha ao processar imagem localmente" }, { status: 500 });
  }
}

