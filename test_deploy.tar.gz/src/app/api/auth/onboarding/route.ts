export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import bcrypt from "bcryptjs";
import crypto from "crypto";
import { MercadoPagoConfig, Preference } from 'mercadopago';

const client = new MercadoPagoConfig({ 
  accessToken: process.env.MERCADOPAGO_ACCESS_TOKEN || '' 
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { 
      name, email, password, 
      storeName, slug, storeType, 
      planId 
    } = body;

    // 1. Validações básicas
    const userExists = await prisma.user.findUnique({ where: { email } });
    if (userExists) return NextResponse.json({ error: "Este e-mail já está cadastrado." }, { status: 400 });

    const slugExists = await prisma.store.findUnique({ where: { slug } });
    if (slugExists) return NextResponse.json({ error: "Este link (slug) já está em uso." }, { status: 400 });

    const plan = await prisma.plan.findUnique({ where: { id: planId } });
    if (!plan) return NextResponse.json({ error: "Plano inválido." }, { status: 400 });

    // 2. Criar Usuário
    const hashedPassword = await bcrypt.hash(password, 12);
    const userId = crypto.randomUUID();
    const user = await prisma.user.create({
      data: {
        id: userId,
        name,
        email,
        password: hashedPassword,
        role: "USER",
        updatedAt: new Date()
      }
    });

    // 3. Criar Loja
    const store = await prisma.store.create({
      data: {
        name: storeName,
        slug,
        storeType, // VITRINE (SHOWCASE) ou RESTAURANT
        whatsapp: "", 
        userId: user.id,
        updatedAt: new Date()
      }
    });

    const trialDate = new Date();
    trialDate.setDate(trialDate.getDate() + 3);

    // 4. Criar Assinatura (3 dias grátis)
    const subscription = await prisma.subscription.create({
      data: {
        storeId: store.id,
        planId: plan.id,
        status: "ACTIVE", // Ativa temporariamente
        expiresAt: trialDate,
      }
    });

    return NextResponse.json({ 
      success: true,
      userId: user.id,
      storeId: store.id
    });

  } catch (error: any) {
    console.error("ONBOARDING ERROR:", error);
    return NextResponse.json({ error: error.message || "Erro ao processar cadastro" }, { status: 500 });
  }
}
