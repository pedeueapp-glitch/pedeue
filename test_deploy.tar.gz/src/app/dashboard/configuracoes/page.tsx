"use client";

import { useState, useEffect, useCallback } from "react";
import { Settings, Save, Loader2, Store, Globe, Phone, MapPin, Star, Sparkles, Check, CheckCircle2 } from "lucide-react";
import toast from "react-hot-toast";

export default function SettingsPage() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [plans, setPlans] = useState<any[]>([]);
  const [currentPlanId, setCurrentPlanId] = useState("");
  const [form, setForm] = useState({
    name: "",
    description: "",
    whatsapp: "",
    deliveryFee: "0",
    minOrderValue: "0",
    isOpen: true,
    address: "",
    city: "",
    state: "",
    primaryColor: "#f97316",
    slug: ""
  });

  const loadData = useCallback(async () => {
    try {
      const [storeRes, plansRes] = await Promise.all([
        fetch("/api/store"),
        fetch("/api/plans")
      ]);
      
      const storeData = await storeRes.json();
      const plansData = await plansRes.json();

      setForm({
        ...storeData,
        deliveryFee: storeData.deliveryFee?.toString() || "0",
        minOrderValue: storeData.minOrderValue?.toString() || "0",
      });
      
      setPlans(plansData);
      setCurrentPlanId(storeData.subscription?.planId || "");
    } catch {
      toast.error("Erro ao carregar configurações");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  async function handleUpdatePlan(planId: string) {
    if (planId === currentPlanId) return;
    
    setSaving(true);
    try {
      const res = await fetch("/api/plans/subscribe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ planId }),
      });
      if (!res.ok) throw new Error();
      setCurrentPlanId(planId);
      toast.success("Plano atualizado com sucesso!");
    } catch {
      toast.error("Erro ao atualizar plano");
    } finally {
      setSaving(false);
    }
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await fetch("/api/store", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (!res.ok) throw new Error();
      toast.success("Configurações salvas com sucesso!");
    } catch {
      toast.error("Erro ao salvar configurações");
    } finally {
      setSaving(false);
    }
  }

  if (loading) return <div className="flex justify-center py-20"><Loader2 className="animate-spin text-purple-500" /></div>;

  return (
    <div className="max-w-4xl animate-fade-in pb-20">
      <div className="mb-8 font-black uppercase">
        <h2 className="text-3xl font-black text-slate-900 tracking-tighter">Configurações</h2>
        <p className="text-slate-400 text-[10px] tracking-widest mt-1">Gestão técnica da sua plataforma</p>
      </div>

      <form onSubmit={handleSave} className="space-y-8">
        {/* INFORMAÇÕES BÁSICAS */}
        <div className="bg-white rounded-[32px] p-10 shadow-sm border border-slate-100">
           <h3 className="text-xs font-black uppercase text-slate-400 tracking-widest mb-8 flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-purple-500/10 flex items-center justify-center text-purple-500"><Store size={16} /></div>
              Dados da Operação
           </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="md:col-span-2">
              <label className="text-[10px] font-black uppercase text-slate-400 mb-2 block ml-1">NOME DA LOJA</label>
              <input 
                type="text" 
                className="w-full bg-slate-50 border-2 border-slate-100 p-5 rounded-2xl font-bold text-sm outline-none focus:border-purple-500 transition-all" 
                value={form.name}
                onChange={e => setForm({...form, name: e.target.value})}
                required
              />
            </div>

            <div>
              <label className="text-[10px] font-black uppercase text-slate-400 mb-2 block ml-1">WHATSAPP DE PEDIDOS</label>
              <div className="relative">
                <Phone className="w-4 h-4 absolute left-5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input 
                  type="text" 
                  className="w-full bg-slate-50 border-2 border-slate-100 p-5 pl-12 rounded-2xl font-bold text-sm outline-none focus:border-purple-500 transition-all" 
                  placeholder="Ex: 5511999999999"
                  value={form.whatsapp}
                  onChange={e => setForm({...form, whatsapp: e.target.value})}
                  required
                />
              </div>
            </div>

            <div>
               <label className="text-[10px] font-black uppercase text-slate-400 mb-2 block ml-1">URL DA LOJA (LINK)</label>
              <div className="relative">
                <Globe className="w-4 h-4 absolute left-5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input 
                  type="text" 
                  className="w-full bg-slate-100 border-2 border-slate-100 p-5 pl-12 rounded-2xl font-bold text-sm text-slate-400 cursor-not-allowed" 
                  value={form.slug}
                  disabled
                />
              </div>
            </div>
          </div>
        </div>

        {/* ENDEREÇO E DELIVERY */}
        <div className="bg-white rounded-[32px] p-10 shadow-sm border border-slate-100">
           <h3 className="text-xs font-black uppercase text-slate-400 tracking-widest mb-8 flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-orange-500/10 flex items-center justify-center text-orange-500"><MapPin size={16} /></div>
              Logística e Entrega
           </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="md:col-span-2">
               <label className="text-[10px] font-black uppercase text-slate-400 mb-2 block ml-1">ENDEREÇO COMPLETO</label>
              <input 
                type="text" 
                className="w-full bg-slate-50 border-2 border-slate-100 p-5 rounded-2xl font-bold text-sm outline-none focus:border-purple-500 transition-all" 
                value={form.address}
                onChange={e => setForm({...form, address: e.target.value})}
              />
            </div>

            <div>
               <label className="text-[10px] font-black uppercase text-slate-400 mb-2 block ml-1">TAXA DE ENTREGA (R$)</label>
              <input 
                type="number" 
                step="0.01"
                className="w-full bg-slate-50 border-2 border-slate-100 p-5 rounded-2xl font-bold text-sm outline-none focus:border-purple-500 transition-all" 
                value={form.deliveryFee}
                onChange={e => setForm({...form, deliveryFee: e.target.value})}
              />
            </div>

            <div>
               <label className="text-[10px] font-black uppercase text-slate-400 mb-2 block ml-1">PEDIDO MÍNIMO (R$)</label>
              <input 
                type="number" 
                step="0.01"
                className="w-full bg-slate-50 border-2 border-slate-100 p-5 rounded-2xl font-bold text-sm outline-none focus:border-purple-500 transition-all" 
                value={form.minOrderValue}
                onChange={e => setForm({...form, minOrderValue: e.target.value})}
              />
            </div>
          </div>
        </div>

        {/* GESTÃO DE PLANO */}
        <div className="bg-white rounded-[32px] p-10 shadow-sm border border-slate-100">
           <h3 className="text-xs font-black uppercase text-slate-400 tracking-widest mb-8 flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-purple-500/10 flex items-center justify-center text-purple-500"><Sparkles size={16} /></div>
              Seu Plano
           </h3>
           
           <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {plans.map(plan => {
                 const isCurrent = plan.id === currentPlanId;
                 return (
                    <button 
                       key={plan.id}
                       type="button"
                       onClick={() => handleUpdatePlan(plan.id)}
                       className={`p-6 rounded-3xl border-2 text-left transition-all relative overflow-hidden group ${isCurrent ? 'bg-purple-600 border-purple-600 shadow-xl shadow-purple-500/20' : 'bg-slate-50 border-slate-100 hover:border-purple-200'}`}
                    >
                       <div className="relative z-10">
                          <p className={`text-[10px] font-black uppercase tracking-widest mb-1 ${isCurrent ? 'text-purple-200' : 'text-slate-400'}`}>Plano</p>
                          <h4 className={`text-lg font-black uppercase tracking-tighter ${isCurrent ? 'text-white' : 'text-slate-900 group-hover:text-purple-500'}`}>{plan.name}</h4>
                          <div className="mt-4 flex items-baseline gap-1">
                             <span className={`text-xl font-black ${isCurrent ? 'text-white' : 'text-slate-900'}`}>{new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(plan.price)}</span>
                             <span className={`text-[10px] font-bold ${isCurrent ? 'text-purple-200' : 'text-slate-400'}`}>/mês</span>
                          </div>
                       </div>
                       {isCurrent && (
                          <div className="absolute top-4 right-4 text-white">
                             <CheckCircle2 size={18} />
                          </div>
                       )}
                    </button>
                 )
              })}
           </div>
           <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-6 bg-slate-50 p-4 rounded-xl inline-block">Teste grátis de 3 dias ativo para novas contas</p>
        </div>

        <div className="flex justify-end gap-4">
          <button 
            type="submit" 
            disabled={saving}
            className="bg-purple-500 text-white px-12 py-5 rounded-2xl font-black uppercase text-xs tracking-widest shadow-xl shadow-purple-500/20 hover:bg-slate-900 transition-all flex items-center gap-2"
          >
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            Salvar Alterações
          </button>
        </div>
      </form>
    </div>
  );
}
