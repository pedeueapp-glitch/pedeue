"use client";

import { useState, useEffect } from "react";
import { 
  Plus, Trash2, Loader2, Image as ImageIcon,
  ChevronRight, AlertCircle, Save, X
} from "lucide-react";
import toast from "react-hot-toast";
import { Header } from "@/components/Header";

export default function BannersPage() {
  const [store, setStore] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [banners, setBanners] = useState<string[]>([]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/store");
      const data = await res.json();
      setStore(data);
      
      let bannerField = "showcaseBanners";
      if (data.storeType === "RESTAURANT") bannerField = "restaurantBanners";
      if (data.storeType === "SERVICE") bannerField = "serviceBanners";
      
      const currentBanners = data[bannerField];
      setBanners(typeof currentBanners === "string" ? JSON.parse(currentBanners || "[]") : (currentBanners || []));
    } catch {
      toast.error("Erro ao carregar dados");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleAddBanner = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const formData = new FormData();
    formData.append("file", file);

    try {
      toast.loading("Enviando imagem...", { id: "upload" });
      const res = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });
      const data = await res.json();
      
      if (data.url) {
        setBanners(prev => [...prev, data.url]);
        toast.success("Imagem enviada!", { id: "upload" });
      }
    } catch {
      toast.error("Erro no upload", { id: "upload" });
    }
  };

  const removeBanner = (index: number) => {
    setBanners(prev => prev.filter((_, i) => i !== index));
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      let bannerField = "showcaseBanners";
      if (store.storeType === "RESTAURANT") bannerField = "restaurantBanners";
      if (store.storeType === "SERVICE") bannerField = "serviceBanners";

      const res = await fetch("/api/store", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          [bannerField]: banners
        }),
      });

      if (!res.ok) throw new Error();
      toast.success("Banners salvos com sucesso!");
    } catch {
      toast.error("Erro ao salvar banners");
    } finally {
      setSaving(false);
    }
  };

  const getModeName = () => {
    if (store?.storeType === "SHOWCASE") return "Vitrine";
    if (store?.storeType === "SERVICE") return "Serviços";
    return "Lanchonete";
  };

  if (loading) return (
    <div className="flex flex-col items-center justify-center min-h-[400px]">
      <Loader2 className="w-10 h-10 animate-spin text-purple-500 mb-4" />
      <span className="font-black uppercase tracking-widest text-[10px] text-slate-400">Carregando...</span>
    </div>
  );

  return (
    <div className="flex flex-col h-full bg-slate-50 pb-20">
      <Header title={`Carrossel de Banners - ${getModeName()}`} />

      <div className="p-6 lg:p-10 max-w-5xl mx-auto w-full">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-12">
          <div>
            <h2 className="text-2xl font-black text-slate-900 tracking-tight italic-none">Gerenciar Destaques</h2>
            <p className="text-slate-400 text-sm mt-1">Imagens que aparecerão no topo do seu catálogo ({getModeName()}).</p>
          </div>
          
          <button 
            onClick={handleSave}
            disabled={saving}
            className="btn-primary flex items-center gap-2 !py-4 !px-8 shadow-xl shadow-purple-500/20 disabled:opacity-50"
          >
            {saving ? <Loader2 className="animate-spin" size={18} /> : <Save size={18} />}
            <span>Salvar Alterações</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
           {/* Botão de Adicionar */}
           <label className="aspect-video bg-white border-4 border-dashed border-slate-200 rounded-[40px] flex flex-col items-center justify-center cursor-pointer hover:bg-slate-50 hover:border-purple-300 transition-all group shadow-sm">
              <div className="w-16 h-16 bg-purple-50 rounded-3xl flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform">
                 <Plus className="text-purple-500" size={32} />
              </div>
              <div className="text-center mt-6">
                <span className="text-xs font-black uppercase text-slate-800 block">Adicionar Novo Banner</span>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1 block">Recomendado: 1200x600px</span>
              </div>
              <input type="file" className="hidden" accept="image/*" onChange={handleAddBanner} />
           </label>

           {/* Listagem de Banners */}
           {(banners || []).map((url, index) => (
              <div key={index} className="aspect-video relative group rounded-[40px] overflow-hidden border-4 border-white shadow-xl">
                 <img src={url} className="w-full h-full object-cover" alt="Banner" />
                 <div className="absolute inset-0 bg-navy/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-sm">
                    <button 
                      type="button"
                      onClick={() => removeBanner(index)}
                      className="w-16 h-16 bg-red-500 text-white rounded-3xl flex items-center justify-center hover:scale-110 transition-transform shadow-2xl"
                    >
                       <Trash2 size={28} />
                    </button>
                 </div>
                 <div className="absolute top-4 left-4 bg-white/20 backdrop-blur-md px-4 py-2 rounded-full border border-white/20">
                    <span className="text-[10px] font-black text-white uppercase tracking-widest">Ordem: {index + 1}</span>
                 </div>
              </div>
           ))}
        </div>

        {(!banners || banners.length === 0) && (
          <div className="mt-12 p-12 bg-white rounded-[40px] border border-slate-100 text-center shadow-sm">
             <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-6 text-slate-300">
                <ImageIcon size={40} />
             </div>
             <h3 className="text-lg font-bold text-slate-800">Nenhum banner ativo</h3>
             <p className="text-xs text-slate-400 mt-2 max-w-xs mx-auto">Adicione imagens para destacar seus produtos ou serviços no topo da página pública.</p>
          </div>
        )}
      </div>
    </div>
  );
}
