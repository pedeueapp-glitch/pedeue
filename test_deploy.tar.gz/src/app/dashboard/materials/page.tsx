"use client";

import { useState, useEffect } from "react";
import { 
  Plus, Search, Edit3, Trash2, Loader2, X,
  Box, Calculator, TrendingUp, AlertCircle
} from "lucide-react";
import toast from "react-hot-toast";
import { Header } from "@/components/Header";
import { ConfirmModal } from "@/components/ConfirmModal";

export default function MaterialsPage() {
  const [materials, setMaterials] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [materialToDelete, setMaterialToDelete] = useState<string | null>(null);
  const [editingMaterial, setEditingMaterial] = useState<any>(null);

  const [formData, setFormData] = useState({
    name: "", quantity: "", purchasePrice: "", profitMargin: ""
  });

  const fetchData = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/materials");
      const data = await res.json();
      setMaterials(Array.isArray(data) ? data : []);
    } catch { toast.error("Erro ao carregar"); } finally { setLoading(false); }
  };

  useEffect(() => { fetchData(); }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const method = editingMaterial ? "PATCH" : "POST";
    const url = "/api/materials";
    try {
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(editingMaterial ? { ...formData, id: editingMaterial.id } : formData),
      });
      if (!res.ok) throw new Error();
      toast.success("Salvo com sucesso!");
      setIsModalOpen(false);
      fetchData();
    } catch { toast.error("Erro ao salvar"); }
  };

  const confirmDelete = async () => {
    if (!materialToDelete) return;
    try {
      const res = await fetch(`/api/materials?id=${materialToDelete}`, { method: "DELETE" });
      if (!res.ok) throw new Error();
      toast.success("Material removido");
      setIsDeleteModalOpen(false);
      setMaterialToDelete(null);
      fetchData();
    } catch { toast.error("Erro ao remover"); }
  };

  const calculateSellingPrice = (purchasePrice: string, margin: string) => {
    const p = parseFloat(purchasePrice || "0");
    const m = parseFloat(margin || "0");
    if (isNaN(p) || isNaN(m)) return 0;
    return p + (p * (m / 100));
  };

  const filteredMaterials = materials.filter(m => m.name.toLowerCase().includes(searchTerm.toLowerCase()));

  return (
    <>
      <Header title="Gestão de Materiais" />

      <div className="p-6 lg:p-10 max-w-7xl mx-auto w-full">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-12">
          <div>
            <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Materiais e Custos</h2>
            <p className="text-slate-400 text-sm mt-1">Gerencie seus insumos e calcule margens de lucro.</p>
          </div>
          
          <div className="flex items-center gap-3 w-full md:w-auto">
            <div className="relative flex-1 sm:w-64">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input 
                type="text" 
                placeholder="Pesquisar..."
                className="input-field pl-11 !rounded-2xl"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
              />
            </div>
            <button 
              onClick={() => {
                setEditingMaterial(null);
                setFormData({ name: "", quantity: "", purchasePrice: "", profitMargin: "" });
                setIsModalOpen(true);
              }}
              className="btn-primary flex items-center gap-2 !py-3.5 !rounded-2xl"
            >
              <Plus size={18} />
              <span>Novo Material</span>
            </button>
          </div>
        </div>

        {loading ? (
          <div className="py-20 flex flex-col items-center justify-center">
            <Loader2 className="w-8 h-8 animate-spin text-purple-500 mb-4" />
            <span className="font-black uppercase tracking-widest text-[10px] text-slate-400">Carregando...</span>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredMaterials.map((material) => (
              <div key={material.id} className="card-premium p-6 flex flex-col gap-4">
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-purple-50 text-purple-500 rounded-xl flex items-center justify-center">
                      <Box size={20} />
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900">{material.name}</h4>
                      <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Estoque: {material.quantity}</p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button 
                      onClick={() => { setEditingMaterial(material); setFormData({ ...material }); setIsModalOpen(true); }}
                      className="p-2 text-slate-400 hover:text-purple-500 transition-colors"
                    >
                      <Edit3 size={16} />
                    </button>
                    <button 
                      onClick={() => { setMaterialToDelete(material.id); setIsDeleteModalOpen(true); }}
                      className="p-2 text-slate-400 hover:text-red-500 transition-colors"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 pt-4 border-t border-slate-50">
                  <div className="bg-slate-50 p-3 rounded-xl">
                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Custo Un.</p>
                    <p className="font-bold text-slate-700 text-sm">R$ {material.purchasePrice.toFixed(2)}</p>
                  </div>
                  <div className="bg-green-50 p-3 rounded-xl">
                    <p className="text-[9px] font-black text-green-600/60 uppercase tracking-widest mb-1">Margem</p>
                    <p className="font-bold text-green-600 text-sm">{material.profitMargin}%</p>
                  </div>
                </div>

                <div className="bg-purple-500 p-4 rounded-xl flex justify-between items-center text-white">
                  <div className="flex items-center gap-2">
                    <Calculator size={16} className="opacity-70" />
                    <span className="text-[10px] font-black uppercase tracking-widest">Preço Sugerido</span>
                  </div>
                  <span className="font-black text-lg">
                    R$ {calculateSellingPrice(material.purchasePrice, material.profitMargin).toFixed(2).replace('.', ',')}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-navy/60 backdrop-blur-md z-[100] flex items-center justify-center p-4">
          <form onSubmit={handleSubmit} className="bg-white w-full max-w-lg rounded-[40px] p-8 lg:p-12 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="flex justify-between items-start mb-10">
              <div>
                <h2 className="text-2xl font-bold text-navy">{editingMaterial ? "Editar Material" : "Novo Material"}</h2>
                <p className="text-slate-400 text-xs mt-1 font-medium">Preencha as informações do insumo.</p>
              </div>
              <button type="button" onClick={() => setIsModalOpen(false)} className="p-2.5 bg-slate-50 rounded-xl text-slate-400"><X size={20}/></button>
            </div>
            
            <div className="space-y-5">
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Nome do Material</label>
                <input className="input-field" placeholder="Ex: Papel Glossy A4" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} required />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Quantidade</label>
                  <input className="input-field" type="number" placeholder="0" value={formData.quantity} onChange={e => setFormData({...formData, quantity: e.target.value})} required />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Preço de Compra (R$)</label>
                  <input className="input-field" type="number" step="0.01" placeholder="0.00" value={formData.purchasePrice} onChange={e => setFormData({...formData, purchasePrice: e.target.value})} required />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Margem de Lucro (%)</label>
                <div className="relative">
                  <TrendingUp className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                  <input className="input-field pl-12" type="number" placeholder="30" value={formData.profitMargin} onChange={e => setFormData({...formData, profitMargin: e.target.value})} required />
                </div>
              </div>

              <div className="p-6 bg-slate-50 rounded-3xl border border-dashed border-slate-200 mt-6">
                <div className="flex justify-between items-center">
                  <span className="text-xs font-bold text-slate-500">Preço de Venda Sugerido:</span>
                  <span className="text-xl font-black text-navy">
                    R$ {calculateSellingPrice(formData.purchasePrice, formData.profitMargin).toFixed(2).replace('.', ',')}
                  </span>
                </div>
              </div>
            </div>

            <button type="submit" className="w-full btn-primary py-4.5 mt-10 rounded-2xl shadow-xl shadow-purple-500/20">
              {editingMaterial ? "Salvar Alterações" : "Cadastrar Material"}
            </button>
          </form>
        </div>
      )}

      <ConfirmModal 
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        onConfirm={confirmDelete}
        title="Excluir Material?"
        message="Esta ação não pode ser desfeita e afetará seu controle de custos."
        confirmText="Excluir Agora"
      />
    </>
  );
}
