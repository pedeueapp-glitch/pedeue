"use client";

import { useState, createContext, useContext, useEffect } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { Sidebar } from "@/components/Sidebar";
import toast from "react-hot-toast";

// Criar um contexto para que qualquer Header dentro das páginas possa abrir a sidebar
const SidebarContext = createContext({
  isOpen: false,
  toggle: () => {},
});

export const useSidebar = () => useContext(SidebarContext);

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [subStatus, setSubStatus] = useState<{ loading: boolean, isExpired: boolean, expiresAt?: string }>({ 
    loading: true, 
    isExpired: false 
  });
  const [isRenewing, setIsRenewing] = useState(false);
  const [isWaitingPayment, setIsWaitingPayment] = useState(false);
  const [prefId, setPrefId] = useState<string | null>(null);

  // 1. Verificação de Autenticação e Assinatura
  useEffect(() => {
    if (status === "unauthenticated") {
      router.push("/entrar");
      return;
    }

    async function checkSubscription() {
      try {
        const res = await fetch("/api/store");
        const data = await res.json();
        
        if (data?.subscription) {
          const expired = new Date(data.subscription.expiresAt) < new Date();
          setSubStatus({ 
            loading: false, 
            isExpired: expired, 
            expiresAt: data.subscription.expiresAt 
          });
        } else {
          setSubStatus({ loading: false, isExpired: true });
        }
      } catch (e: any) {
        setSubStatus({ loading: false, isExpired: false });
      }
    }

    if (status === "authenticated") {
      checkSubscription();
    }
  }, [status, router]);

  // 2. Polling de Pagamento
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isWaitingPayment && prefId) {
      interval = setInterval(async () => {
        try {
          const res = await fetch(`/api/checkout/mercadopago/check?preference_id=${prefId}`);
          if (res.ok) {
            clearInterval(interval);
            setIsWaitingPayment(false);
            toast.success("Pagamento confirmado! Acesso liberado.");
            window.location.reload();
          }
        } catch (e: any) {}
      }, 5000);
    }
    return () => clearInterval(interval);
  }, [isWaitingPayment, prefId]);

  const toggle = () => setIsSidebarOpen(!isSidebarOpen);

  const handleQuickRenew = async () => {
    try {
      setIsRenewing(true);
      const resStore = await fetch("/api/store");
      const storeData = await resStore.json();
      
      if (!storeData?.subscription?.planId) {
        toast.error("Plano não encontrado. Entre em contato com o suporte.");
        return;
      }

      const res = await fetch("/api/checkout/mercadopago", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          planId: storeData.subscription.planId,
          storeId: storeData.id
        })
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error);
      
      setPrefId(json.preference_id);
      window.open(json.init_point, "_blank");
      setIsWaitingPayment(true);
    } catch (error: any) {
      toast.error(error.message || "Erro ao processar pagamento");
    } finally {
      setIsRenewing(false);
    }
  };

  // 3. Loading State
  if (status === "loading" || (status === "authenticated" && subStatus.loading)) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="flex flex-col items-center gap-4">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-500"></div>
          <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Validando Acesso...</p>
        </div>
      </div>
    );
  }

  if (!session) return null;

  // 4. Bloqueio por Assinatura
  const isPlanPage = typeof window !== 'undefined' && window.location.pathname.includes('/dashboard/plano');
  
  if (subStatus.isExpired && !isPlanPage) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center p-6 overflow-hidden relative">
        {/* UI do bloqueio... */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-purple-500/10 rounded-full blur-[120px] -mr-48 -mt-48" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-500/10 rounded-full blur-[120px] -ml-48 -mb-48" />

        <div className="w-full max-w-lg bg-white/5 backdrop-blur-xl border border-white/10 p-12 rounded-[40px] text-center relative z-10 shadow-2xl">
          <div className="w-20 h-20 bg-red-500/20 border border-red-500/30 rounded-3xl flex items-center justify-center mx-auto mb-8 shadow-[0_0_40px_rgba(239,68,68,0.2)]">
            <svg className="w-10 h-10 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 15v2m0 0v2m0-2h2m-2 0H10m11-3V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2h11l4 4V12z" />
            </svg>
          </div>

          <h1 className="text-3xl font-black text-white uppercase tracking-tighter mb-4">
            {isWaitingPayment ? "AGUARDANDO PAGAMENTO" : "ACESSO BLOQUEADO"}
          </h1>
          
          <p className="text-slate-400 text-sm font-bold uppercase tracking-widest mb-10 leading-relaxed">
            {isWaitingPayment 
              ? "Estamos verificando seu pagamento em tempo real. Não feche esta página."
              : `Sua assinatura ${subStatus.expiresAt ? `venceu em ${new Date(subStatus.expiresAt).toLocaleDateString()}` : 'não foi encontrada'}. Renove agora para continuar vendendo.`}
          </p>

          <div className="space-y-4">
             {isWaitingPayment ? (
               <div className="py-8 flex flex-col items-center gap-4">
                  <div className="w-12 h-12 border-4 border-purple-500/20 border-t-purple-500 rounded-full animate-spin" />
                  <span className="text-[10px] font-black text-purple-500 animate-pulse tracking-[0.3em]">SINCRONIZANDO...</span>
                  <button onClick={() => window.location.reload()} className="text-xs text-slate-500 hover:text-white underline">Já paguei, recarregar agora</button>
               </div>
             ) : (
               <>
                 <button 
                  onClick={handleQuickRenew}
                  disabled={isRenewing}
                  className="w-full bg-purple-500 hover:bg-purple-600 text-white py-6 rounded-2xl font-black uppercase tracking-[0.2em] transition-all shadow-xl shadow-purple-500/20 disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {isRenewing ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : "Pagar com Mercado Pago"}
                </button>
                
                <button 
                  onClick={() => router.push("/dashboard/plano")}
                  className="w-full bg-white/5 hover:bg-white/10 text-white py-6 rounded-2xl font-black uppercase tracking-[0.2em] transition-all border border-white/10"
                >
                  Ver Outros Planos
                </button>
               </>
             )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <SidebarContext.Provider value={{ isOpen: isSidebarOpen, toggle }}>
      <div className="flex min-h-screen bg-slate-50/50">
        <Sidebar 
          isOpen={isSidebarOpen} 
          onClose={() => setIsSidebarOpen(false)} 
        />
        
        <main className="flex-1 flex flex-col min-w-0">
          {children}
        </main>
      </div>
    </SidebarContext.Provider>
  );
}
