import { redirect } from "next/navigation";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export default async function SuperAdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session = await getServerSession(authOptions);

  // Se não estiver logado ou não for SUPERADMIN, volta para o login
  if (!session || (session.user as any).role !== "SUPERADMIN") {
    redirect("/entrar");
  }

  return (
    <div className="min-h-screen bg-[#f8fafc]">
      {children}
    </div>
  );
}
